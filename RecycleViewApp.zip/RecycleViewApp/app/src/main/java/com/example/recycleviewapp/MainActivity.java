package com.example.recycleviewapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    private String tvTitles[];
    private String tvDes[];
    private String tvTyp[];
    private String tvGen[];
    int images[] = {R.drawable.theoffice, R.drawable.spongebob, R.drawable.myhero, R.drawable.strangerthings, R.drawable.friends,
            R.drawable.gameofthrones,R.drawable.ilovelucy, R.drawable.modernfamily, R.drawable.thesimpsons, R.drawable.umbrellaacademy };


    private RecyclerView mRecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvTitles = getResources().getStringArray(R.array.tvshowTitles);
        tvDes   = getResources().getStringArray(R.array.tvDescription);
        tvTyp = getResources().getStringArray(R.array.tvTypes);
        tvGen =getResources().getStringArray(R.array.genres);
        recyclerView =findViewById(R.id.recyclerView);



MyAdapter myAdapter = new MyAdapter(this, tvTitles,tvDes,tvTyp,tvGen,images );
recyclerView.setAdapter(myAdapter);
recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
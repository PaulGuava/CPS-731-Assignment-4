package com.example.recycleviewapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    private String tvTitles[];
    private String tvDes[];
    int images[] = {R.drawable.theoffice, R.drawable.spongebob, R.drawable.myhero, R.drawable.strangerthings, R.drawable.friends };


    private RecyclerView mRecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvTitles = getResources().getStringArray(R.array.tvshowTitles);
        tvDes   = getResources().getStringArray(R.array.tvDescription);

        recyclerView =findViewById(R.id.recyclerView);



MyAdapter myAdapter = new MyAdapter(this, tvTitles,tvDes,images );
recyclerView.setAdapter(myAdapter);
recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
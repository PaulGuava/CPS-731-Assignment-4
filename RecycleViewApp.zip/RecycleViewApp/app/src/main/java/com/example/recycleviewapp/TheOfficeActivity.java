package com.example.recycleviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class TheOfficeActivity extends AppCompatActivity {

    ImageView mainImageView;
    TextView title, description;

    String titleDetail, descriptionDetail;
    int imageDetail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_office);

        mainImageView =findViewById(R.id.myimageView);
        title = findViewById(R.id.titletxt);
        description = findViewById(R.id.descriptiontxt);

        getData();
        setData();

    }

    private void getData(){
        if(getIntent().hasExtra("imageViewIn") && getIntent().hasExtra("titleIn") && getIntent().hasExtra("descriptionIn"))
        {
        titleDetail = getIntent().getStringExtra("titleIn");
        descriptionDetail= getIntent().getStringExtra("descriptionIn");
        imageDetail = getIntent().getIntExtra("imageViewIn",1);
        }
        else{
            Toast.makeText(this, "No Data.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setData()
    {
        title.setText(titleDetail);
        description.setText(descriptionDetail);
        mainImageView.setImageResource(imageDetail);
    }
}
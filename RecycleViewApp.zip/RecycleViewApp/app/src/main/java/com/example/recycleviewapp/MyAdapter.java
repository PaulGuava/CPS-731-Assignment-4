package com.example.recycleviewapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    String tvTit[], tvDes[];
    int images[];
    Context context;
    public MyAdapter (Context c, String tvT[], String tvD[], int imgs[]){
    context = c;
    tvTit = tvT;
    tvDes = tvD;
    images = imgs;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.the_row, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
    holder.myText1.setText(tvTit[position]);
    holder.myText2.setText(tvDes[position]);
    holder.myImage.setImageResource(images[position]);

    holder.mainLayout.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){
            Intent intent = new Intent(context, TheOfficeActivity.class);
            intent.putExtra("titleInside",tvTit[position]);
            intent.putExtra("descriptionInside",tvDes[position]);
            intent.putExtra("imageViewInside",images[position]);
            context.startActivity(intent);
        }
    });

    }

    @Override
    public int getItemCount() {
        return tvTit.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {


        TextView myText1, myText2;
        ImageView myImage;
        ConstraintLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            myText1 = itemView.findViewById(R.id.titletxt);
            myText2 = itemView.findViewById(R.id.descriptiontxt);
            myImage = itemView.findViewById(R.id.myimageView);
            mainLayout = itemView.findViewById(R.id.mainLayout);

        }
    }
}

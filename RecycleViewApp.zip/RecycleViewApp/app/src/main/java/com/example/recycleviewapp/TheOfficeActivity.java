package com.example.recycleviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class TheOfficeActivity extends AppCompatActivity {

    ImageView mainImageView;
    TextView title, description;

    String titleDetail, descriptionDetail, gen;
    int imageDetail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_office);

        mainImageView =findViewById(R.id.imageViewInside);
        title = findViewById(R.id.titleInside);
        description = findViewById(R.id.descriptionInside);

        getData();
        setData();

    }

    private void getData(){
        if(getIntent().hasExtra("images") && getIntent().hasExtra("tvTit") && getIntent().hasExtra("tvDes"))
        {
        titleDetail = getIntent().getStringExtra("tvTit");
        descriptionDetail= getIntent().getStringExtra("tvDes");
        imageDetail = getIntent().getIntExtra("images",1);
        gen = getIntent().getStringExtra("genre");
            Toast.makeText(this, gen, Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(this, "No Data.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setData()
    {
        title.setText(titleDetail);
        description.setText(descriptionDetail);
        mainImageView.setImageResource(imageDetail);
    }
}
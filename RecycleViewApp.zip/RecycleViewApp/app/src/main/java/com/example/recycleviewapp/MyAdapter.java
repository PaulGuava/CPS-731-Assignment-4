package com.example.recycleviewapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    String tvTit[];
        String tvDes[];
        String tvTy[];
        String tvGen[];
    int images[];
    Context context;
    public MyAdapter (Context c, String tvT[], String tvD[],String tvTyper[],String gen[], int imgs[]){
    context = c;
    tvTit = tvT;
    tvDes = tvD;
    tvTy = tvTyper;
    tvGen = gen;
    images = imgs;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.the_row, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
    holder.tit.setText(tvTit[position]);
    holder.typ.setText(tvTy[position]);
    holder.myImage.setImageResource(images[position]);

    holder.mainLayout.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){
            Intent intent = new Intent(context, TheOfficeActivity.class);
            intent.putExtra("tvTit",tvTit[position]);
            intent.putExtra("tvDes",tvDes[position]);
            intent.putExtra("images",images[position]);
            intent.putExtra("genre",tvGen[position]);
            context.startActivity(intent);
        }
    });

    }

    @Override
    public int getItemCount() {
        return tvTit.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {


        TextView tit, des, typ;
        ImageView myImage;
        LinearLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tit = itemView.findViewById(R.id.titletxt);
            typ = itemView.findViewById(R.id.typetxt);
            myImage = itemView.findViewById(R.id.myimageView);
            mainLayout = itemView.findViewById(R.id.mainLayout);

        }
    }
}
